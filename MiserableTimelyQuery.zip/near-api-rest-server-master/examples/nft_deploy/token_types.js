const prefix = "test";
module.exports = {
    data: [
        {
            token_type: prefix + '_name_1',
            metadata: {media: 'hash_1'}
        },
        {
            token_type: prefix + '_name_2',
            metadata: {media: 'hash_2'}
        },
        {
            token_type: prefix + '_name_3',
            metadata: {media: 'hash_3'}
        },
    ]
};